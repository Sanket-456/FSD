let slides = document.querySelectorAll(".slide");
let index = 0;
let interval;

let slider = document.querySelector(".slider");

slider.addEventListener("mouseover", () => clearInterval(interval));
slider.addEventListener("mouseout", startAutoSlide);

// Show slide
function showSlide(i) {
    slides.forEach(s => s.classList.remove("active"));
    slides[i].classList.add("active");
}

// Next
function nextSlide() {
    index = (index + 1) % slides.length;
    showSlide(index);
    resetAutoSlide();
}

// Previous
function prevSlide() {
    index = (index - 1 + slides.length) % slides.length;
    showSlide(index);
    resetAutoSlide();
}

// AUTO SLIDE FUNCTION
function startAutoSlide() {
    interval = setInterval(nextSlide, 3000); // 3 sec
}

// RESET TIMER when user clicks
function resetAutoSlide() {
    clearInterval(interval);
    startAutoSlide();
}

// Start on load
startAutoSlide();