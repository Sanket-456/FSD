<?php
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

// Instead of sending mail, just show success
echo "<h2>Mail Sent Successfully!</h2>";
echo "Name: $name <br>";
echo "Email: $email <br>";
echo "Message: $message <br>";
?>