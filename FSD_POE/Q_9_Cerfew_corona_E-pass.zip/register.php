<?php
$conn = mysqli_connect("localhost", "root", "", "DB");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$full_name = $_POST['full_name'];
$mobile_number = $_POST['mobile_number'];
$address = $_POST['address'];
$purpose = $_POST['purpose'];
$vehicle_number = $_POST['vehicle_number'];

$stmt = $conn->prepare("INSERT INTO users (full_name, mobile_number, address, purpose, vehicle_number) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $full_name, $mobile_number, $address, $purpose, $vehicle_number);

if ($stmt->execute()) {
    echo "E-Pass Application Submitted Successfully!";
} else {
    echo "Error: " . $stmt->error;
}

$conn->close();
?>
