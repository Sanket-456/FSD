SETUP INSTRUCTIONS:

1. Install XAMPP and start Apache & MySQL.
2. Copy this folder into:
   C:\xampp\htdocs\

3. Open phpMyAdmin:
   http://localhost/phpmyadmin

4. Create database using db.sql file.

5. Run project:
   http://localhost/Q_Epass_Project/reg.html

Done.
