const http = require('http');
const { URL } = require('url');

const server = http.createServer((req, res) => {

    // Modern URL parsing
    const fullUrl = new URL(req.url, `http://${req.headers.host}`);
    const query = Object.fromEntries(fullUrl.searchParams);

    res.writeHead(200, { 'Content-Type': 'application/json' });

    if (req.method === 'GET') {
        res.end(JSON.stringify({
            method: "GET",
            message: "GET request received",
            queryParams: query
        }));
    }

    else if (req.method === 'POST') {
        let body = '';

        req.on('data', chunk => {
            body += chunk;
        });

        req.on('end', () => {
            let parsedBody;

            try {
                parsedBody = body ? JSON.parse(body) : {};
            } catch (error) {
                parsedBody = { error: "Invalid JSON" };
            }

            res.end(JSON.stringify({
                method: "POST",
                message: "POST request received",
                queryParams: query,
                body: parsedBody
            }));
        });
    }

    else {
        res.end(JSON.stringify({
            message: "Unsupported request method"
        }));
    }
});

server.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});