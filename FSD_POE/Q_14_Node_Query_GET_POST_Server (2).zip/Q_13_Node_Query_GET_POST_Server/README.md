# Node.js Query String GET & POST Server

## ⚙️ Prerequisites

* Node.js installed
* VS Code installed
* REST Client extension installed in VS Code


## 🚀 How to Run the Project

1. Run:
   npm install

2. Start server:
   npm start

3. Server will run at:
   http://localhost:3000

---

## 🧪 Testing Using REST Client (Recommended)

### Step 1: Create a file

Create a new file in your project:
test.http

---

### Step 2: Add the following code

### GET Request

GET http://localhost:3000/?name=Sanket&age=21

###

### POST Request

POST http://localhost:3000/?id=101
Content-Type: application/json

{
"course": "CS",
"year": 3
}

---

### Step 3: Run Requests

* Click **"Send Request"** above each request
* Response will open in a new tab inside VS Code

---
