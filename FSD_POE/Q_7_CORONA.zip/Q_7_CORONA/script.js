document.getElementById("covidForm").addEventListener("submit", function(e){

    let name = document.getElementById("name").value.trim();
    let mobile = document.getElementById("mobile").value.trim();
    let age = document.getElementById("age").value;
    let aadhar = document.getElementById("aadhar").value.trim();

    let namePattern = /^[A-Za-z ]+$/;
    if(!name.match(namePattern)){
        alert("Name should contain only letters");
        e.preventDefault();
        return;
    }

    let mobilePattern = /^[0-9]{10}$/;
    if(!mobile.match(mobilePattern)){
        alert("Mobile number must be 10 digits");
        e.preventDefault();
        return;
    }

    if(age < 1 || age > 120){
        alert("Enter valid age");
        e.preventDefault();
        return;
    }

    let aadharPattern = /^[0-9]{12}$/;
    if(!aadhar.match(aadharPattern)){
        alert("Aadhar must be 12 digits");
        e.preventDefault();
        return;
    }

    alert("Registration Successful!");
});
