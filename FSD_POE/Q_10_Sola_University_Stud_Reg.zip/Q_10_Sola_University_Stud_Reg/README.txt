SETUP STEPS:

1. Install XAMPP and start Apache & MySQL.
2. Copy folder to:
   C:\xampp\htdocs\

3. Open:
   http://localhost/phpmyadmin

4. Import db.sql file.

5. Run:
   http://localhost/Q_10_Sola_University_Stud_Reg/reg.html
