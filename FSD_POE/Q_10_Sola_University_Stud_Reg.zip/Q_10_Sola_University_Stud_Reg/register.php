<?php
$conn = mysqli_connect("localhost", "root", "", "DB");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$name = $_POST['name'];
$dob = $_POST['dob'];
$gender = $_POST['gender'];
$email = $_POST['email'];
$address = $_POST['address'];
$school = $_POST['school'];
$department = $_POST['department'];
$course = $_POST['course'];
$mobile = $_POST['mobile'];

$stmt = $conn->prepare("INSERT INTO users (name, dob, gender, email, address, school, department, course, mobile) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssssss", $name, $dob, $gender, $email, $address, $school, $department, $course, $mobile);

if ($stmt->execute()) {
    echo "Registration Successful!";
} else {
    echo "Error: " . $stmt->error;
}

$conn->close();
?>
