Install mongoDB , make sure the serbver is running .
npm install 
http://localhost:3000/register.html
http://localhost:3000/login.html