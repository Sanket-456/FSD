const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const session = require('express-session');
const User = require('./models/User');

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.use(session({
    secret: 'secretkey',
    resave: false,
    saveUninitialized: true
}));

mongoose.connect('mongodb://127.0.0.1:27017/loginDB')
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));

app.post('/register', async (req, res) => {
    const { username, password } = req.body;

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = new User({ username, password: hashedPassword });
    await user.save();

    res.send('User Registered');
});

app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    const user = await User.findOne({ username });

    if (!user) return res.send('User not found');

    const isMatch = await bcrypt.compare(password, user.password);

    if (isMatch) {
        req.session.user = user;
        res.send('Login Successful <a href="/dashboard">Go Dashboard</a>');
    } else {
        res.send('Invalid Password');
    }
});

app.get('/dashboard', (req, res) => {
    if (req.session.user) {
        res.send("Welcome " + req.session.user.username + " <br><a href='/logout'>Logout</a>");
    } else {
        res.send("Login first");
    }
});

app.get('/logout', (req, res) => {
    req.session.destroy();
    res.send("Logged out");
});

app.listen(3000, () => console.log("Server running on http://localhost:3000"));
