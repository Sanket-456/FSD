# Q_21 PHP User Authentication

## Features
- User Registration
- Secure Login
- Password Hashing
- Session Management
- Protected Dashboard

## Setup

1. Copy folder to:
   C:\xampp\htdocs\

2. Start Apache & MySQL

3. Open phpMyAdmin:
   http://localhost/phpmyadmin

4. Import db.sql

5. Run:
   http://localhost/Q_21_PHP_User_Authentication/register.html

## Flow
Register → Login → Dashboard → Logout

## Security
- password_hash()
- password_verify()
- Prepared statements