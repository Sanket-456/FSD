function getUser() {
    let username = document.getElementById("username").value.trim();
    let output = document.getElementById("output");

    if (username === "") {
        output.innerHTML = "<p style='color:red;'>Please enter username</p>";
        return;
    }

    let url = "https://api.github.com/users/" + username;
    let xhr = new XMLHttpRequest();

    xhr.open("GET", url, true);

    xhr.onload = function () {
        if (xhr.status === 200) {
            let user = JSON.parse(xhr.responseText);

            let html = `
                <h3>User Details</h3>
                <p><b>Name:</b> ${user.name || "N/A"}</p>
                <p><b>Login:</b> ${user.login}</p>
                <p><b>Public Repos:</b> ${user.public_repos}</p>
            `;

            let repoXHR = new XMLHttpRequest();
            repoXHR.open("GET", user.repos_url, true);

            repoXHR.onload = function () {
                let repos = JSON.parse(repoXHR.responseText);

                html += "<h3>Repositories:</h3><ul>";

                repos.forEach(repo => {
                    html += `<li>${repo.name}</li>`;
                });

                html += "</ul>";
                output.innerHTML = html;
            };

            repoXHR.send();

        } else if (xhr.status === 404) {
            output.innerHTML = "<p style='color:red;'>User not found ❌</p>";
        }
    };

    xhr.send();
}
