function loadData() {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", "data.json", true);

    xhr.onload = function() {
        if (xhr.status === 200) {
            const data = JSON.parse(xhr.responseText);
            const tableBody = document.querySelector("#dataTable tbody");
            tableBody.innerHTML = "";

            data.forEach(item => {
                const row = `<tr>
                    <td>${item.id}</td>
                    <td>${item.name}</td>
                    <td>${item.course}</td>
                    <td>${item.year}</td>
                </tr>`;
                tableBody.innerHTML += row;
            });
        }
    };

    xhr.send();
}
