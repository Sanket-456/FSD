SETUP STEPS:

1. Start XAMPP (Apache + MySQL)
2. Copy folder to C:\xampp\htdocs\
3. Open phpMyAdmin and import db.sql
4. Run http://localhost/Q_19_Simple_Event_Registration/reg.html
