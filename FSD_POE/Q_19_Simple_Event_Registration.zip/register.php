<?php
$conn = mysqli_connect("localhost", "root", "", "DB");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$title = $_POST['title'];
$company = $_POST['company'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$customer = $_POST['customer'];

$stmt = $conn->prepare("INSERT INTO users (first_name, last_name, title, company, email, phone, customer) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssss", $first_name, $last_name, $title, $company, $email, $phone, $customer);

if ($stmt->execute()) {
    echo "Registration Successful!";
} else {
    echo "Error: " . $stmt->error;
}

$conn->close();
?>
