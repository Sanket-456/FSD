CREATE DATABASE DB;

USE DB;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    title VARCHAR(100),
    company VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(15),
    customer VARCHAR(10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
