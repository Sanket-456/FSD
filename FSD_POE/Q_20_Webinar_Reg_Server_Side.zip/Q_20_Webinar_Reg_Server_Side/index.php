<?php
// Simple trigger page (no form required)
echo "<h3>Click to simulate registration</h3>";
echo "<a href='register.php'>Run Registration Script</a>";
?>
