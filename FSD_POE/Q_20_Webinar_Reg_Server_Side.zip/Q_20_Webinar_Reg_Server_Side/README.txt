SETUP:

1. Copy folder to C:\xampp\htdocs\
2. Start Apache & MySQL
3. Import db.sql in phpMyAdmin
4. Option 1 (Without HTML)
http://localhost/Q_20_Webinar_Reg_Server_Side/

Click the link → data will be inserted using simulated POST.

Option 2 (With HTML Form)
http://localhost/Q_20_Webinar_Reg_Server_Side/reg.html

Fill form → Submit → Data stored in database.

NOTE:
- No HTML form required (as per question)
- register.php can simulate POST data for testing
