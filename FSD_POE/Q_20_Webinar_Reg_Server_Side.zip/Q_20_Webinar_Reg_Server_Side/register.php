<?php
// register.php
$conn = mysqli_connect("localhost", "root", "", "DB");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Allow testing without HTML by seeding POST
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $_POST['company'] = "ABC Pvt Ltd";
    $_POST['first_name'] = "Test";
    $_POST['last_name'] = "User";
    $_POST['email'] = "test@example.com";
    $_POST['phone'] = "9876543210";
    $_POST['address'] = "Sample Address";
    $_POST['city'] = "Pune";
    $_POST['state'] = "Maharashtra";
}

$company = $_POST['company'];
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$city = $_POST['city'];
$state = $_POST['state'];

$stmt = $conn->prepare("INSERT INTO users (company, first_name, last_name, email, phone, address, city, state) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssss", $company, $first_name, $last_name, $email, $phone, $address, $city, $state);

if ($stmt->execute()) {
    echo "Registration Successful";
} else {
    echo "Error: " . $stmt->error;
}

$conn->close();
?>
