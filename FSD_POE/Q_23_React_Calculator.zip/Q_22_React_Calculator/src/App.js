import React, { useState } from "react";
import "./App.css";

function App() {
  const [expression, setExpression] = useState("");
  const [result, setResult] = useState("0");

  const isOperator = (val) => ["+", "-", "*", "/"].includes(val);

  const handleClick = (value) => {
    if (value === "C") {
      setExpression("");
      setResult("0");
      return;
    }

    if (value === "⌫") {
      setExpression((prev) => prev.slice(0, -1));
      return;
    }

    if (value === "=") {
      try {
        const evalResult = eval(expression);
        setResult(evalResult.toString());
      } catch {
        setResult("Error");
      }
      return;
    }

    setExpression((prev) => {
      // Prevent multiple operators
      if (isOperator(value) && isOperator(prev.slice(-1))) {
        return prev.slice(0, -1) + value;
      }
      return prev + value;
    });
  };

  return (
    <div className="container">
      <div className="calculator">

        {/* Display */}
        <div className="display">
          <div className="expression">{expression || "0"}</div>
          <div className="result">{result}</div>
        </div>

        {/* Buttons */}
        <div className="grid">

          <button onClick={() => handleClick("C")} className="clear">C</button>
          <button onClick={() => handleClick("⌫")}>⌫</button>
          <button onClick={() => handleClick("/")}>÷</button>
          <button onClick={() => handleClick("*")}>×</button>

          <button onClick={() => handleClick("7")}>7</button>
          <button onClick={() => handleClick("8")}>8</button>
          <button onClick={() => handleClick("9")}>9</button>
          <button onClick={() => handleClick("-")}>-</button>

          <button onClick={() => handleClick("4")}>4</button>
          <button onClick={() => handleClick("5")}>5</button>
          <button onClick={() => handleClick("6")}>6</button>
          <button onClick={() => handleClick("+")}>+</button>

          <button onClick={() => handleClick("1")}>1</button>
          <button onClick={() => handleClick("2")}>2</button>
          <button onClick={() => handleClick("3")}>3</button>
          <button onClick={() => handleClick("=")} className="equal">=</button>

          <button onClick={() => handleClick("0")} className="zero">0</button>
          <button onClick={() => handleClick(".")}>.</button>

        </div>
      </div>
    </div>
  );
}

export default App;