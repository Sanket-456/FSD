# Q_22 React Calculator

## Setup
1. Install Node.js
2. Extract folder
3. Open terminal inside project
4. Run:
   npm install
   npm start

## Features
- Basic arithmetic operations
- React Hooks (useState)
- Simple UI

## Note
Uses eval() for simplicity (not recommended for production)
