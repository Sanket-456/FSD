document.getElementById("epassForm").addEventListener("submit", function(e) {

    let name = document.getElementById("name").value.trim();
    let contact = document.getElementById("contact").value.trim();
    let email = document.getElementById("email").value.trim();
    let date = document.getElementById("date").value;

    let namePattern = /^[A-Za-z ]+$/;
    if (!name.match(namePattern)) {
        alert("Name should contain only letters");
        e.preventDefault();
        return;
    }

    let contactPattern = /^[0-9]{10}$/;
    if (!contact.match(contactPattern)) {
        alert("Contact number must be 10 digits");
        e.preventDefault();
        return;
    }

    let emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    if (!email.match(emailPattern)) {
        alert("Enter valid email");
        e.preventDefault();
        return;
    }

    let today = new Date().toISOString().split("T")[0];
    if (date < today) {
        alert("Date cannot be in the past");
        e.preventDefault();
        return;
    }

    alert("E-PASS Registration Successful!");
});
