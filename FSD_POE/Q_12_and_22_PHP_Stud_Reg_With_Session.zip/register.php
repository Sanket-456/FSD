<?php
session_start();

$conn = mysqli_connect("localhost", "root", "", "DB");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$name = $_POST['name'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$course = $_POST['course'];

// store in session
$_SESSION['name'] = $name;
$_SESSION['email'] = $email;

$stmt = $conn->prepare("INSERT INTO users (name, email, mobile, course) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $name, $email, $mobile, $course);

if ($stmt->execute()) {
    header("Location: success.php");
} else {
    echo "Error: " . $stmt->error;
}

$conn->close();
?>
