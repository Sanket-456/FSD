<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Success</title>
</head>
<body>

<h2>Registration Successful</h2>

<p>Welcome, <?php echo $_SESSION['name']; ?>!</p>
<p>Email: <?php echo $_SESSION['email']; ?></p>

<a href="logout.php">Logout</a>

</body>
</html>
