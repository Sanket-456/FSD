<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Student Registration</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h2 style="text-align:center;">Student Registration</h2>

<form action="register.php" method="POST">

<div class="form-group">
<label>Name:</label>
<input type="text" name="name" required>
</div>

<div class="form-group">
<label>Email:</label>
<input type="email" name="email" required>
</div>

<div class="form-group">
<label>Mobile:</label>
<input type="text" name="mobile" pattern="[0-9]{10}" required>
</div>

<div class="form-group">
<label>Course:</label>
<input type="text" name="course" required>
</div>

<div class="buttons">
<input type="submit" value="Register">
</div>

</form>

</body>
</html>
