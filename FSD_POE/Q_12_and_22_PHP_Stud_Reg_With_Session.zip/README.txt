SETUP:

1. Start XAMPP (Apache + MySQL)
2. Copy folder to htdocs
3. Import db.sql in phpMyAdmin
4. Run: http://localhost/Q_12_PHP_Stud_Reg_With_Session/index.php

SESSION FLOW:
- Data stored in session after form submit
- Displayed on success page
- Logout destroys session
