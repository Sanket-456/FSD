document.getElementById("form").addEventListener("submit", function(e){

    let name = document.getElementById("name").value.trim();
    let mobile = document.getElementById("mobile").value.trim();
    let age = document.getElementById("age").value;
    let year = document.getElementById("year").value;

    let namePattern = /^[A-Za-z ]+$/;
    if(!name.match(namePattern)){
        alert("Invalid Name");
        e.preventDefault();
        return;
    }

    let mobilePattern = /^[0-9]{10}$/;
    if(!mobile.match(mobilePattern)){
        alert("Invalid Mobile Number");
        e.preventDefault();
        return;
    }

    if(age < 17 || age > 100){
        alert("Invalid Age");
        e.preventDefault();
        return;
    }

    let currentYear = new Date().getFullYear();
    if(year < 2000 || year > currentYear){
        alert("Invalid Passout Year");
        e.preventDefault();
        return;
    }

    alert("Registration Successful");
});
