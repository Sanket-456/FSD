npm install 
node server.js

package.json
{
  "name": "university-project",
  "version": "1.0.0",
  "main": "server.js",
  "type": "commonjs",
  "scripts": {
    "start": "node server.js"
  },
  "dependencies": {
    "axios": "^1.6.0",
    "express": "^5.2.1"
  }
}



in case it did not work 
Remove-Item -Recurse -Force node_modules
Remove-Item package-lock.json
and paste the package .json 
then npm intall