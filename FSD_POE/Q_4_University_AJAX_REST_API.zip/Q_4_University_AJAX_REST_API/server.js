const express = require('express');
const axios = require('axios');
const app = express();

app.use(express.static(__dirname));

// API route
app.get('/api', async (req, res) => {
    const country = req.query.country;

    if (!country) {
        return res.status(400).json({ error: "Country is required" });
    }

    try {
        const response = await axios.get(
            "http://universities.hipolabs.com/search?country=" + encodeURIComponent(country)
        );

        res.json(response.data);

    } catch (error) {
        console.error("ERROR:", error.message);
        res.status(500).json({ error: "Failed to fetch data" });
    }
});

app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});